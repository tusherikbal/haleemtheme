<?php

/**
 * Plugin Name: Theme Feature
 * Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
 * Description: A brief description of the Plugin.
 * Version: The Plugin's Version Number, e.g.: 1.0
 * Author: Name Of The Plugin Author
 * Author URI: http://URI_Of_The_Plugin_Author
 * License: A "Slug" license name e.g. GPL2
 */










//slider part

function custom_post_haleem() {

	register_post_type( 'slider', array(

        'labels'=> array(
        
                'name' => __( 'slider', 'wp-haleem' ),
                'singular_name'=> __( 'slider', 'wp-haleem' ),
    ),

    'public'             => true,
    'show_ui'              => true,
    'publicly_queryable' => true,
    'rewrite'            => array( 'slug' => 'slider' ),		
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments','custom-fields' ),
    'menu_icon' => 'dashicons-slides'
));



//services 


register_post_type( 'services', array(

                'labels'=> array(
                
                        'name' => __( 'Services', 'wp-haleem' ),
                        'singular_name'=> __( 'Service', 'wp-haleem' ),
            ),

            'public'             => true,
            'show_ui'              => true,
            'publicly_queryable' => true,
            'rewrite'            => array( 'slug' => 'service' ),		
            'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments','custom-fields' ),
            'menu_icon' => 'dashicons-list-view'
            
));

	
//counter section

register_post_type( 'counter', array(

    'labels'=> array(
    
            'name' => __( 'Counters', 'wp-haleem' ),
            'singular_name'=> __( 'Counter', 'wp-haleem' ),
),

'public'             => true,
'show_ui'              => true,
'publicly_queryable' => true,
'rewrite'            => array( 'slug' => 'service' ),		
'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments','custom-fields' ),
'menu_icon' => 'dashicons-marker'


));


//team members
register_post_type( 'teams', array(

    'labels'=> array(
    
            'name' => __( 'Team', 'wp-haleem' ),
            'singular_name'=> __( 'Team', 'wp-haleem' ),
),

'public'             => true,
'show_ui'              => true,
'publicly_queryable' => true,
'rewrite'            => array( 'slug' => 'team' ),		
'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments','custom-fields' ),
'menu_icon' => 'dashicons-buddicons-buddypress-logo'
));



//testmonial

register_post_type( 'testmonial', array(

    'labels'=> array(
    
            'name' => __( 'Testmonial', 'wp-haleem' ),
            'singular_name'=> __( 'Testmonial', 'wp-haleem' ),
),

'public'             => true,
'show_ui'              => true,
'publicly_queryable' => true,
'rewrite'            => array( 'slug' => 'testmonial' ),		
'supports'           => array( 'title', 'thumbnail','custom-fields' ),
'menu_icon' => 'dashicons-testimonial'
));


//portfolio
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => __('Portfolios', 'wp-haleem'),
            'singular_name' => __('Portfolio', 'wp-haleem')
        ),

    'public' => true,
    'show_ui' => true,
    'supports' => array('title','editor','thumbnail','custom-fields'),
    'menu_icon' => 'dashicons-portfolio'


    ));

    //category add korar jnno 'register_taxonomy' function add korte hbe.

    register_taxonomy( 'portfolio-category', 'portfolio', array(
        'labels' => array(
            'name' => __('categories', 'wp-haleem'),
            'singular_name' => __('category', 'wp-haleem')
        ),

        'hierarchical' => true,
        'show_admin_menu'=> true


    ) );




    //gallary 

    register_post_type('gallary', array(
        'labels' => array(
            'name' => __('gallary_aLL', 'wp-haleem'),
            'singular_name' => __('gallary_item', 'wp-haleem')
        ),

    'public' => true,
    'show_ui' => true,
    'supports' => array('title','thumbnail','custom-fields'),
    'menu_icon' => 'dashicons-format-gallery'


    ));


}




add_action( 'init', 'custom_post_haleem' );
